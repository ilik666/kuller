module.exports = {
	testEnvironment: "jsdom",
};
